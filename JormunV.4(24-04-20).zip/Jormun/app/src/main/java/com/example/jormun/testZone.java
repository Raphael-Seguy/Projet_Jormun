package com.example.jormun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class testZone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_zone);
    }
}
