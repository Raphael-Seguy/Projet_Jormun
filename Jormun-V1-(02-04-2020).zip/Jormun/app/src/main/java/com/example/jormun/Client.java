package com.example.jormun;

import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import java.net.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.io.*;

public class Client{
    public static final String USER_BUSY = "BUSY";
    public static final String USER_FREE = "FREE";
    public static final String USER_LOGGIN = "LOGGIN";
    public static final String USER_EXITING = "EXITING";

    OutputStream outToServer;
    Socket sktClient;
    DataOutputStream dtoutstrmToServer;
    DataInputStream dtinstrmBackToClient;
    InputStream inFromServer;
    String sUsername = "TestingTube";


    public Client(String sIp, int iPort,LatLng ltlngStartPos){
        Socket sktTemp;

        String sMessage;
        try {
            sktTemp = new Socket(sIp, iPort);
            setSktClient(sktTemp);
            setOutToServer(sktTemp.getOutputStream());
            setDtoutstrmToServer(new DataOutputStream(outToServer));
            setInFromServer(sktTemp.getInputStream());
            setDtinstrmBackToClient(new DataInputStream(inFromServer));
            setsUsername(this.sUsername);
            sMessage = encryptPassword(getsUsername())+"@"+ltlngStartPos.latitude+"#"+ltlngStartPos.longitude;
            Log.println(Log.DEBUG,"Debug",sMessage);
            dtoutstrmToServer.writeUTF(sMessage);
            if(dtinstrmBackToClient.readUTF().equals("420")){
                Log.println(Log.INFO,"Connection","Connection was successful");
                dtoutstrmToServer.writeUTF(this.getsUsername()+"@"+Client.USER_FREE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("Client built");
    }
    public void SendUserStatus(String sStatus){
        try {
            dtoutstrmToServer.writeUTF(this.getsUsername()+"@"+sStatus);
        } catch (IOException e) {
            Log.println(Log.ERROR, "Connection", "Fail to send message");
        }
    }
    public void SendUserPosition(LatLng ltlngPosition) {
        try {
            dtoutstrmToServer.writeUTF(this.getsUsername()+"@"+ltlngPosition.latitude + "#" + ltlngPosition.longitude);
        } catch (IOException e) {
            Log.println(Log.ERROR, "Connection", "Fail to send message");
        }
    }
    private static String encryptPassword(String password)
    {
        String sha1 = "";
        try
        {
            MessageDigest crypt = MessageDigest.getInstance("SHA-1");
            crypt.reset();
            crypt.update(password.getBytes("UTF-8"));
            sha1 = byteToHex(crypt.digest());
        }
        catch(NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        catch(UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        return sha1;
    }

    private static String byteToHex(final byte[] hash)
    {
        Formatter formatter = new Formatter();
        for (byte b : hash)
        {
            formatter.format("%02x", b);
        }
        String result = formatter.toString();
        formatter.close();
        return result;
    }
    public Socket getSktClient() {
        return sktClient;
    }

    public void setSktClient(Socket sktClient) {
        this.sktClient = sktClient;
    }

    public DataOutputStream getDtoutstrmToServer() {
        return dtoutstrmToServer;
    }

    public void setDtoutstrmToServer(DataOutputStream dtoutstrmToServer) {
        this.dtoutstrmToServer = dtoutstrmToServer;
    }

    public DataInputStream getDtinstrmBackToClient() {
        return dtinstrmBackToClient;
    }

    public void setDtinstrmBackToClient(DataInputStream dtinstrmBackToClient) {
        this.dtinstrmBackToClient = dtinstrmBackToClient;
    }

    public InputStream getInFromServer() {
        return inFromServer;
    }

    public void setInFromServer(InputStream inFromServer) {
        this.inFromServer = inFromServer;
    }

    public String getsUsername() {
        return this.sUsername;
    }

    public void setsUsername(String sUsername) {
        this.sUsername = sUsername;
    }

    public OutputStream getOutToServer() {
        return outToServer;
    }

    public void setOutToServer(OutputStream outToServer) {
        this.outToServer = outToServer;
    }

}