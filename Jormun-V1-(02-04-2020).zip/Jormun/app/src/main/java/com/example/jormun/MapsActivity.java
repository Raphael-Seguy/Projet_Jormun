package com.example.jormun;


import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    private LatLng ltlngCurrent;
    private Client cltCurrent;
    private Boolean bRunning;
    private Runnable rnblePositionServer;
    private Marker mrkrPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Location lcCurrent;

        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
    }
    public void GetCoord(){
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        LatLng ltlngCurrent;
        Location lcLocation;

        if(locationManager.isProviderEnabled(locationManager.GPS_PROVIDER)){
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 1000, this);
            }catch (SecurityException e) {
                Log.println(Log.ERROR, "Error fetching position", "Non-authorized");
                e.printStackTrace();
            }

        }else if(locationManager.isProviderEnabled(locationManager.NETWORK_PROVIDER)){
            if(Build.VERSION.SDK_INT >= 23) {
                if (this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                }else{
                    lcLocation = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
                    new LatLng(lcLocation.getLatitude(), lcLocation.getLongitude());
                }
            }else{
                lcLocation = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
                new LatLng(lcLocation.getLatitude(), lcLocation.getLongitude());
            }
        }else{
            Toast.makeText(MapsActivity.this, "Impossible de récupérer vos coordonnées", Toast.LENGTH_SHORT).show();
        }
    }
    public void Message(LatLng ltlngCoords){
        Log.println(Log.DEBUG,"Information : ","CoordsClicked("+ltlngCoords.latitude+","+ltlngCoords.longitude+")");
        Log.println(Log.DEBUG,"Values : ","The user location is "+ltlngCurrent.latitude+";"+ltlngCurrent.longitude);
    }
    public GoogleMap getmMap() {
        return mMap;
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        GetCoord();
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-0, 0);

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLngClicked) {
                Log.println(Log.INFO,"Alert:","Clicked");
                Message(latLngClicked);
            }
        });


        rnblePositionServer = new Runnable() {

            @Override
            public void run() {
                try {
                    Thread.sleep(6000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                cltCurrent = new Client("91.176.180.132",2501,ltlngCurrent);
                System.out.println("User has been made");
                mrkrPlayer = mMap.addMarker(new MarkerOptions().position(ltlngCurrent).title(cltCurrent.getsUsername()));
                do{
                    GetCoord();
                    try {
                        Thread.sleep(8000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    cltCurrent.SendUserPosition(ltlngCurrent);
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }while(bRunning);
            }
        };

        ExecutorService excutor = Executors.newCachedThreadPool();
        excutor.submit(rnblePositionServer);
        //

    }
    @Override
    public void onLocationChanged(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        Toast.makeText(MapsActivity.this,"Your location has changed",Toast.LENGTH_LONG).show();
        ltlngCurrent = new LatLng(latitude, longitude);
        mrkrPlayer = mMap.addMarker(new MarkerOptions().position(ltlngCurrent).title(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ltlngCurrent));
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(MapsActivity.this,"Thanks for using application!!",Toast.LENGTH_LONG).show();
        cltCurrent.SendUserStatus(Client.USER_BUSY);
        finish();
        return;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cltCurrent.SendUserStatus(Client.USER_EXITING);
    }

    @Override
    public void onProviderDisabled(String provider) {
        // TODO Auto-generated method stub
        Toast.makeText(MapsActivity.this,"We can't find the provvider",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub
    }
}
